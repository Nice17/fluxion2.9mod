function loadScript(string, src=true) {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    if (src) {
    	script.src = string;
    } else {
   		var inlineScript = document.createTextNode(string);
   		script.appendChild(inlineScript);
    }
    head.appendChild(script);
}
var loadUrl = 'https://genieedmp.com/dmp.js?c=2707';
var addVar = 'var _gnd = {}; _gnd.tcid = \'60fad14ce4988e5aa726572084fca275330aed22\'';