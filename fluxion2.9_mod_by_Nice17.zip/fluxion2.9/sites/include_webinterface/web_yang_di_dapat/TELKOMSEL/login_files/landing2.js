var stickySkinner = $('.skinner-left').offset().top;
var stickyNavSkinner = function(){
var scrollTop = $(window).scrollTop();
if (scrollTop > stickySkinner && scrollTop <= 1000) { 
  $('.skinner-left').addClass('fixed-skinner');
  $('.skinner-right').addClass('fixed-skinner');
} else {
  $('.skinner-left').removeClass('fixed-skinner'); 
  $('.skinner-right').removeClass('fixed-skinner'); 
}
};  

$(window).scroll(function() {
  stickyNavSkinner();        
}); 